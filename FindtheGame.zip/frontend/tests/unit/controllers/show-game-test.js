import { moduleFor, test } from 'ember-qunit';

moduleFor('controller:show-game', 'Unit | Controller | show game', {
  // Specify the other units that are required for this test.
  // needs: ['controller:foo']
});

// Replace this with your real tests.
test('it exists', function(assert) {
  let controller = this.subject();
  assert.ok(controller);
});
