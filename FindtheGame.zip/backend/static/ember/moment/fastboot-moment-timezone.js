(function() {
  define('moment', ['exports'], function(self) {
    self['default'] = FastBoot.require('moment-timezone');
  });
})();
